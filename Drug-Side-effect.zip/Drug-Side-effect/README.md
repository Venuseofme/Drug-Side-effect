# Drug-Side-effect

Source code for the prediction of drug-induced anemia side effects using a
graph neural network with molecular descriptors and molecular graphs as input.

## Repository structure

```
data_processing/     build molecular graphs from SMILES
  descriptors.py     calculate RDKit descriptors and keep the selected ones
  features.py        atom-level and bond-level features
  graph_utils.py     assemble a DGL graph for one molecule
  dataset.py         load the dataset and build graphs in bulk
  main.py            entry point for data preparation

model_building/      train and evaluate the model
  config.py          hyperparameters of the model
  model_building.py  GCN architecture
  model_training.py  training loop
  model_testing.py   evaluation on the test set
  main.py            entry point for training and testing
```

## Requirements

Tested with Python 3.9.

```
pip install -r requirements.txt
```

RDKit is most easily installed with conda:

```
conda install -c conda-forge rdkit
```

## Usage

1. Prepare the data. Edit `DATA_FILE` and `SAVE_DIR` in
   `data_processing/main.py`, then run

   ```
   cd data_processing
   python main.py
   ```

   The input CSV must contain the SMILES string in the first column. This step
   writes `train_graphs.npy` and `test_graphs.npy`.

2. Train and evaluate the model. Edit the file paths at the top of
   `model_building/main.py`, then run

   ```
   cd model_building
   python main.py
   ```

   This step trains the GCN, saves the weights to `GCN.pkl` and prints the
   accuracy on the test set.

## Hyperparameters

All hyperparameters are defined in `model_building/config.py`. The values
correspond to those reported in the manuscript, and the search space explored
during tuning is given in the comments. Training runs for at most 150 epochs
with early stopping at a patience of 20 epochs, monitored on the training
accuracy, and the weights of the best epoch are restored before evaluation.
