# model_building.py
import dgl
import torch
import torch.nn as nn
from dgl.nn.pytorch import GraphConv

from config import DROPOUT, RANDOM_SEED


class GCN(torch.nn.Module):
    """Three-layer graph convolutional network with dropout and mean pooling."""

    def __init__(self, in_feats, h_feats, num_classes, dropout=DROPOUT):
        super(GCN, self).__init__()
        torch.manual_seed(RANDOM_SEED)
        self.conv1 = GraphConv(in_feats, h_feats, allow_zero_in_degree=True)
        self.conv2 = GraphConv(h_feats, h_feats, allow_zero_in_degree=True)
        self.conv3 = GraphConv(h_feats, h_feats, allow_zero_in_degree=True)
        self.dropout = nn.Dropout(dropout)
        self.classify = torch.nn.Linear(h_feats, num_classes)

    def forward(self, g):
        h = g.ndata['x']
        h = self.dropout(self.conv1(g, h).relu())
        h = self.dropout(self.conv2(g, h).relu())
        h = self.dropout(self.conv3(g, h).relu())
        g.ndata['h'] = h
        hg = dgl.mean_nodes(g, 'h')
        return self.classify(hg)
