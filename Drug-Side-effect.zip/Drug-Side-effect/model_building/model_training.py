# model_training.py
import copy

import dgl
import torch
import torch.nn as nn

from config import (BATCH_SIZE, HIDDEN_FEATS, LEARNING_RATE, MAX_EPOCHS,
                    MIN_DELTA, NUM_CLASSES, PATIENCE)
from model_building import GCN


def _batches(graphs, labels, batch_size):
    """Yield batched graphs and the corresponding label tensors."""
    for i in range(0, len(graphs), batch_size):
        chunk_g = graphs[i:i + batch_size]
        chunk_y = labels[i:i + batch_size]
        yield dgl.batch(chunk_g), torch.as_tensor(chunk_y).long().view(-1)


def train_model(train_graphs, train_labels,
                epochs=MAX_EPOCHS, lr=LEARNING_RATE,
                hidden_feats=HIDDEN_FEATS, num_classes=NUM_CLASSES,
                batch_size=BATCH_SIZE, patience=PATIENCE, min_delta=MIN_DELTA):
    """
    Train the GCN model.

    Training runs for at most `epochs` epochs. Early stopping is applied with
    the given patience, monitored on the training accuracy; the weights of the
    best epoch are restored before the model is returned.
    """
    model = GCN(train_graphs[0].ndata['x'].shape[1], hidden_feats, num_classes)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    best_acc, best_epoch = -1.0, 0
    best_state = copy.deepcopy(model.state_dict())

    for epoch in range(1, epochs + 1):
        model.train()
        epoch_loss, correct, total = 0.0, 0, 0
        n_batches = 0

        for bg, by in _batches(train_graphs, train_labels, batch_size):
            logits = model(bg)
            loss = criterion(logits, by)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            epoch_loss += loss.detach().item()
            n_batches += 1
            correct += (logits.argmax(dim=1) == by).sum().item()
            total += by.numel()

        epoch_loss /= max(n_batches, 1)
        accuracy = correct / max(total, 1)
        print(f'Epoch {epoch}, Loss: {epoch_loss:.4f}, Accuracy: {accuracy:.4f}')

        if accuracy > best_acc + min_delta:
            best_acc, best_epoch = accuracy, epoch
            best_state = copy.deepcopy(model.state_dict())
        elif epoch - best_epoch >= patience:
            print(f'Early stopping at epoch {epoch}; '
                  f'no improvement since epoch {best_epoch}.')
            break

    print(f'Best epoch: {best_epoch}, accuracy: {best_acc:.4f}')
    model.load_state_dict(best_state)
    return model
