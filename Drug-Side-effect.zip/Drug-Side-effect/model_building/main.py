# main.py
import numpy as np
import torch

from config import HIDDEN_FEATS
from model_testing import test_model
from model_training import train_model

TRAIN_GRAPHS_PATH = 'train_graphs.npy'
TRAIN_LABELS_PATH = 'train_labels.npy'
TEST_GRAPHS_PATH = 'test_graphs.npy'
TEST_LABELS_PATH = 'test_labels.npy'
MODEL_PATH = 'GCN.pkl'


def load_data(train_graphs_path, train_labels_path):
    """Load the training graphs and labels."""
    train_graphs = np.load(train_graphs_path, allow_pickle=True).tolist()
    train_labels = np.load(train_labels_path, allow_pickle=True).tolist()
    return train_graphs, train_labels


def main():
    train_graphs, train_labels = load_data(TRAIN_GRAPHS_PATH, TRAIN_LABELS_PATH)

    model = train_model(train_graphs, train_labels)
    torch.save(model.state_dict(), MODEL_PATH)

    test_model(MODEL_PATH, TEST_GRAPHS_PATH, TEST_LABELS_PATH,
               hidden_feats=HIDDEN_FEATS)


if __name__ == "__main__":
    main()
