# config.py
"""
Hyperparameters of the multimodal GNN model.

The values below must match those reported in the manuscript. The search
spaces explored during hyperparameter tuning are given in the comments.
"""

# Architecture
HIDDEN_FEATS = 128        # searched over {64, 128, 256}
DROPOUT = 0.3             # searched over {0.1, 0.3, 0.5}
NUM_CLASSES = 2

# Optimisation
LEARNING_RATE = 0.001     # searched over {0.0001, 0.001, 0.01}
BATCH_SIZE = 20
MAX_EPOCHS = 150
PATIENCE = 20             # early stopping patience, in epochs
MIN_DELTA = 0.0           # minimum improvement counted as progress
RANDOM_SEED = 1234
