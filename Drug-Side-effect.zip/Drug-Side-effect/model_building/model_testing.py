# model_testing.py
import dgl
import numpy as np
import torch
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score, roc_auc_score)

from config import BATCH_SIZE, HIDDEN_FEATS, NUM_CLASSES
from model_building import GCN


def test_model(model_path, test_graphs_path, test_labels_path,
               hidden_feats=HIDDEN_FEATS, num_classes=NUM_CLASSES,
               batch_size=BATCH_SIZE):
    """Load a trained model and report accuracy, precision, recall, F1, FNR and AUC."""
    test_labels = np.asarray(
        np.load(test_labels_path, allow_pickle=True).tolist()).ravel()
    test_graphs = np.load(test_graphs_path, allow_pickle=True).tolist()

    model = GCN(test_graphs[0].ndata['x'].shape[1], hidden_feats, num_classes)
    model.load_state_dict(torch.load(model_path))
    model.eval()

    probs = []
    with torch.no_grad():
        for i in range(0, len(test_graphs), batch_size):
            bg = dgl.batch(test_graphs[i:i + batch_size])
            probs.append(torch.softmax(model(bg), dim=1)[:, 1].cpu().numpy())
    probs = np.concatenate(probs)
    preds = (probs >= 0.5).astype(int)

    metrics = {
        'accuracy': accuracy_score(test_labels, preds),
        'precision': precision_score(test_labels, preds, zero_division=0),
        'recall': recall_score(test_labels, preds, zero_division=0),
        'f1': f1_score(test_labels, preds, zero_division=0),
        'auc': roc_auc_score(test_labels, probs),
    }
    metrics['fnr'] = 1.0 - metrics['recall']

    for name, value in metrics.items():
        print(f'{name:>10}: {value:.4f}')
    return metrics
