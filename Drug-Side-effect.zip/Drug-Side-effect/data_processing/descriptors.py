# descriptors.py
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors

# Critical molecular descriptors retained after SHAP-based feature selection.
# The 50 descriptors below are those used by the multimodal GNN model.
SELECTED_DESCRIPTORS = [
    'NumHeterocycles', 'fr_aryl_methyl', 'BCUT2D_CHGHI', 'BCUT2D_LOGPLOW',
    'EState_VSA3', 'VSA_EState8', 'MaxAbsPartialCharge', 'qed',
    'FpDensityMorgan1', 'FpDensityMorgan3', 'SlogP_VSA8', 'SlogP_VSA10',
    'PEOE_VSA11', 'BCUT2D_CHGLO', 'AvgIpc', 'BCUT2D_LOGPHI',
    'BCUT2D_MRHI', 'SlogP_VSA6', 'NumAliphaticRings', 'PEOE_VSA9',
    'BCUT2D_MRLOW', 'VSA_EState1', 'EState_VSA7', 'FpDensityMorgan2',
    'SMR_VSA6', 'EState_VSA4', 'MolLogP', 'PEOE_VSA1',
    'SPS', 'SlogP_VSA1', 'EState_VSA2', 'BalabanJ',
    'MinAbsEStateIndex', 'EState_VSA9', 'PEOE_VSA8', 'TPSA',
    'SlogP_VSA3', 'SMR_VSA10', 'VSA_EState2', 'SlogP_VSA5',
    'VSA_EState7', 'VSA_EState3', 'SMR_VSA5', 'SlogP_VSA2',
    'Kappa3', 'SMR_VSA3', 'VSA_EState4', 'Phi',
    'HallKierAlpha', 'VSA_EState5',
]


def get_md(mol):
    """Calculate all RDKit descriptors for one molecule."""
    calc = MoleculeDescriptors.MolecularDescriptorCalculator(
        [x[0] for x in Descriptors._descList])
    return np.asarray(calc.CalcDescriptors(mol))


def get_descriptors(smiles):
    """Return the selected molecular descriptors for one SMILES string."""
    smiles = str(smiles)
    data = pd.DataFrame([smiles], columns=['SMILES'])
    data['Mol'] = data['SMILES'].apply(Chem.MolFromSmiles)
    data['descriptors'] = data['Mol'].apply(get_md)
    des_list = [x[0] for x in Descriptors._descList]
    des = {des_list[i]: [t[i] for t in data['descriptors']]
           for i in range(len(des_list))}
    des_df = pd.DataFrame(des)
    return des_df[SELECTED_DESCRIPTORS]
