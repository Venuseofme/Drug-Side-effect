# dataset.py
import pandas as pd
from graph_utils import build_molecular_graph
from descriptors import get_descriptors


def load_data(file_path):
    """Load the drug dataset from a CSV file."""
    return pd.read_csv(file_path, index_col=0)


def prepare_dataset(data, start, end):
    """Build molecular graphs for the rows in [start, end)."""
    smiles_list = data.iloc[start:end, 0]
    graphs = []
    for smiles in smiles_list:
        rdkit_data = get_descriptors(smiles).values[0]
        graphs.append(build_molecular_graph(smiles, rdkit_data))
    return graphs
