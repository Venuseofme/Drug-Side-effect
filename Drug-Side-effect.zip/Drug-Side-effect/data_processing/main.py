# main.py
import numpy as np
from dataset import load_data, prepare_dataset

DATA_FILE = "path/to/dataset.csv"   # CSV with SMILES in the first column
SAVE_DIR = "./processed"
TRAIN_END = 1800                    # rows [0, TRAIN_END) form the training set
TEST_END = 2500                     # rows [TRAIN_END, TEST_END) form the test set


def main():
    # Load the dataset
    data = load_data(DATA_FILE)

    # Build the molecular graphs
    train_graphs = prepare_dataset(data, 0, TRAIN_END)
    test_graphs = prepare_dataset(data, TRAIN_END, TEST_END)

    # Save the graphs for model training and testing
    np.save(f"{SAVE_DIR}/train_graphs.npy", train_graphs)
    np.save(f"{SAVE_DIR}/test_graphs.npy", test_graphs)

    print("Data preparation and saving completed.")


if __name__ == "__main__":
    main()
